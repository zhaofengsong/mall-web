export default {
	collapseMenu(state) {
		state.isCollapse = !state.isCollapse;
	},

}
