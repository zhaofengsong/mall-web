export default {
	saveUserInfo(state, payload) {
		state.userInfo = payload;
	},
}
